# GURI — Final Integrated Prototype

Guri is a permission-based personal AI assistant:
voice/text -> AI brain -> tools -> approval -> action -> audit.

Included:
- Android client source (Kotlin)
- Flask backend
- AI provider adapter
- multilingual text/voice architecture
- tool registry and approval queue
- audit log
- Trend Radar
- Content Factory
- social publishing architecture
- music workflow
- freelancing workflow
- scheduler/reminders
- security policy
- Guri OFF
- browser demo dashboard

This is a complete SOURCE prototype. Real phone actions, social accounts and
AI providers still require explicit permissions, OAuth credentials and provider
configuration. AI secrets never belong inside the Android app.
