package com.guri.assistant

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale

data class ChatLine(val who:String,val text:String)

class MainActivity:ComponentActivity(){
 private val speech=registerForActivityResult(
  ActivityResultContracts.StartActivityForResult()){r->
   val t=r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
   if(!t.isNullOrBlank()) GuriState.input=t
  }
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),50)
  setContent{GuriApp{startVoice()}}
 }
 private fun startVoice(){
  val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
  i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
  i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.getDefault())
  i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Guri ko bolo...")
  speech.launch(i)
 }
}
object GuriState{var input by mutableStateOf("")}

@Composable
fun GuriApp(onVoice:()->Unit){
 var messages by remember{mutableStateOf(listOf(
  ChatLine("GURI","Sat Sri Akal! Main Guri hoon. Voice ya text command do.")
 ))}
 var input by remember{mutableStateOf("")}
 LaunchedEffect(GuriState.input){input=GuriState.input}
 MaterialTheme{
  Column(Modifier.fillMaxSize().padding(16.dp)){
   Text("GURI",style=MaterialTheme.typography.headlineLarge)
   Text("Personal AI Assistant")
   Spacer(Modifier.height(12.dp))
   LazyColumn(Modifier.weight(1f).fillMaxWidth()){
    items(messages){m->Text("${m.who}: ${m.text}",Modifier.padding(vertical=6.dp))}
   }
   Row(Modifier.fillMaxWidth()){
    OutlinedTextField(value=input,onValueChange={input=it},
     modifier=Modifier.weight(1f),placeholder={Text("Guri ko bolo...")})
    Spacer(Modifier.width(8.dp))
    Button(onClick=onVoice){Text("🎙")}
   }
   Spacer(Modifier.height(8.dp))
   Button(onClick={
    if(input.isNotBlank()){
     messages=messages+ChatLine("YOU",input)+
       ChatLine("GURI","Android API client next connects this command to your backend.")
     input=""
    }
   },Modifier.fillMaxWidth()){Text("Send")}
  }
 }
}
