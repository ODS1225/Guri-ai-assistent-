The Android source contains the UI and microphone entry point.
The remaining production integration is the HTTPS API client plus individual
approved Android intents. Do not add root shell, covert recording or unrestricted
AccessibilityService control.
