# GURI architecture

ANDROID voice/text UI
        |
      HTTPS
        v
BACKEND
  Conversation Manager
        |
        +-- AI Brain
        +-- Security Policy
        +-- Approval Queue
        +-- Tool Registry
        |     +-- Android actions
        |     +-- Web
        |     +-- Scheduler
        |     +-- Trend Radar
        |     +-- Content Factory
        |     +-- Social Publishing
        |     +-- Music
        |     +-- Freelancing
        +-- Audit Log
        +-- Memory

Rule:
AI proposes -> security validates -> approval when required -> tool executes
-> result -> audit.
