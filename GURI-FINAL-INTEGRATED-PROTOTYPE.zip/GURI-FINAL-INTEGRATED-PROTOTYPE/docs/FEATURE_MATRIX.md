# Feature matrix

| Feature | Prototype status | Production work |
|---|---|---|
| Hindi/English/Punjabi/Hinglish | Yes | provider tuning |
| Text assistant | Yes | AI credentials |
| Voice input | Android entry point | API + TTS |
| Memory | SQLite | optional encrypted sync |
| Tool calling | Yes | more Android executors |
| Approval system | Yes | UI polish |
| Audit | Yes | optional remote storage |
| Guri OFF | Yes | device-level UX |
| Trend Radar | starter | more sources/ranking |
| Content Factory | workflow | media providers |
| Social media | architecture | official OAuth/APIs |
| Music | workflow | audio providers |
| Freelancing | workflow | files/email/platform connectors |
| Banking | blocked | intentionally unsupported |
