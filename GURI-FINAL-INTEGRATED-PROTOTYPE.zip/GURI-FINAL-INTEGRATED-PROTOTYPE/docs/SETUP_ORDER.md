# Setup order

1. Configure backend environment and AI provider.
2. Run backend and test /health.
3. Open dashboard/index.html and set GURI_BASE and GURI_TOKEN in localStorage.
4. Test text chat.
5. Build Android source.
6. Connect Android HTTPS API client.
7. Test microphone.
8. Add safe Android intents one at a time.
9. Add Trend Radar and Content Factory.
10. Add official social OAuth.
11. Add media/audio providers.
12. Test permissions, approvals and failure cases before enabling each new tool.

Never put an AI API key in the APK.
