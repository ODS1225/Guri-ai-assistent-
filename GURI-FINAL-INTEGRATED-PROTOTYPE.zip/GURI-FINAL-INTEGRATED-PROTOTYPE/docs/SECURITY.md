# Security

- AI keys stay server-side.
- HTTPS in production.
- Unknown tools are denied.
- Banking/UPI/OTP/PIN/payment actions are denied.
- Side-effecting tools require approval.
- Every execution/rejection is audited.
- Guri OFF stops assistant actions.
- No arbitrary shell/root tool.
- No covert microphone recording.
- No password collection.
- Use official OAuth/API flows for social platforms.
