import os
DEVICE_TOKEN=os.getenv("GURI_DEVICE_TOKEN","")
AI_BASE_URL=os.getenv("AI_BASE_URL","").rstrip("/")
AI_API_KEY=os.getenv("AI_API_KEY","")
AI_MODEL=os.getenv("AI_MODEL","")
GURI_OFF=os.getenv("GURI_OFF","false").lower()=="true"
DB_PATH=os.getenv("GURI_DB","./guri.db")
