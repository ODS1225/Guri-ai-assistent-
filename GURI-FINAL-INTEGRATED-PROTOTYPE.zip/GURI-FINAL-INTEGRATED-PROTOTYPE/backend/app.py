from flask import Flask,request,jsonify
from config import DEVICE_TOKEN,GURI_OFF
from db import *
from provider import Provider,ProviderError
from security import validate,needs_approval
from tools import execute

app=Flask(__name__); provider=Provider()

def auth():
    return bool(DEVICE_TOKEN) and request.headers.get("Authorization")==f"Bearer {DEVICE_TOKEN}"

@app.get("/health")
def health(): return jsonify(ok=True,version="FINAL-PROTOTYPE",guri_off=GURI_OFF)

@app.post("/api/conversations")
def conversations():
    if not auth():return jsonify(error="unauthorized"),401
    return jsonify(conversation_id=create_conversation())

@app.get("/api/conversations/<cid>/messages")
def get_messages(cid):
    if not auth():return jsonify(error="unauthorized"),401
    return jsonify(messages=messages(cid))

@app.post("/api/chat")
def chat():
    if not auth():return jsonify(error="unauthorized"),401
    if GURI_OFF:return jsonify(error="guri_off",text="Guri OFF hai."),503
    b=request.get_json(silent=True) or {}
    cid=b.get("conversation_id"); text=b.get("message",""); lang=b.get("language","auto")
    if not cid or not conversation_exists(cid):return jsonify(error="conversation_not_found"),404
    if not isinstance(text,str) or not text.strip():return jsonify(error="message_required"),400
    add_message(cid,"user",text.strip())
    try:r=provider.chat(messages(cid),lang)
    except ProviderError as e:return jsonify(error="provider_error",detail=str(e)),502
    call=r.get("tool_call")
    if call:
        ok,reason=validate(call)
        if not ok:r={"text":reason,"tool_call":None,"requires_approval":False}
        elif needs_approval(call):
            r["approval_id"]=approval_create(call); r["requires_approval"]=True
        else:
            result=execute(call); r["tool_result"]=result; r["requires_approval"]=False
            audit("tool_execution",{"call":call,"result":result})
    add_message(cid,"assistant",r.get("text",""))
    audit("chat",{"conversation_id":cid,"language":lang,"tool":call})
    return jsonify(conversation_id=cid,**r)

@app.get("/api/approvals")
def get_approvals():
    if not auth():return jsonify(error="unauthorized"),401
    return jsonify(items=approvals_pending())

@app.post("/api/approvals/<aid>/approve")
def approve(aid):
    if not auth():return jsonify(error="unauthorized"),401
    item=approval_get(aid)
    if not item:return jsonify(error="approval_not_found"),404
    ok,reason=validate(item["tool_call"])
    if not ok:return jsonify(error=reason),403
    result=execute(item["tool_call"]); approval_finish(aid,"completed",result)
    audit("approved_execution",{"approval_id":aid,"result":result})
    return jsonify(result=result)

@app.post("/api/approvals/<aid>/reject")
def reject(aid):
    if not auth():return jsonify(error="unauthorized"),401
    item=approval_get(aid)
    if not item:return jsonify(error="approval_not_found"),404
    approval_finish(aid,"rejected"); audit("rejected_execution",{"approval_id":aid})
    return jsonify(ok=True)

@app.get("/api/trends")
def trends():
    if not auth():return jsonify(error="unauthorized"),401
    from trends import search
    return jsonify(search(request.args.get("q","")))

@app.post("/api/content/plan")
def content_plan():
    if not auth():return jsonify(error="unauthorized"),401
    from content import plan
    b=request.get_json(silent=True) or {}
    return jsonify(plan(b.get("topic",""),b.get("platform","Instagram/YouTube"),b.get("language","Hinglish")))

@app.get("/api/audit")
def audit_endpoint():
    if not auth():return jsonify(error="unauthorized"),401
    return jsonify(items=audit_list())

if __name__=="__main__":
    app.run(host="0.0.0.0",port=8787)
