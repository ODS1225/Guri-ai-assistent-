BLOCKED_TERMS={
 "upi","banking","bank account","credit card","debit card",
 "otp","payment transfer","money transfer","net banking","password","pin"
}

TOOLS={
 "web.open_url":{"approval":True,"description":"Open an HTTPS website on the user's device.",
   "schema":{"type":"object","properties":{"url":{"type":"string"}},"required":["url"]}},
 "scheduler.create_reminder":{"approval":True,"description":"Create a reminder.",
   "schema":{"type":"object","properties":{"text":{"type":"string"},"run_at":{"type":"string"}},"required":["text","run_at"]}},
 "device.show_notification":{"approval":True,"description":"Show a notification on Android.",
   "schema":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
 "device.share_text":{"approval":True,"description":"Open the Android share sheet.",
   "schema":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
 "trend.search":{"approval":False,"description":"Search configured trend feeds.",
   "schema":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
 "content.make_plan":{"approval":False,"description":"Create a short-form content plan.",
   "schema":{"type":"object","properties":{"topic":{"type":"string"},"platform":{"type":"string"},"language":{"type":"string"}},"required":["topic"]}},
 "content.generate_assets":{"approval":False,"description":"Create a production checklist.",
   "schema":{"type":"object","properties":{"topic":{"type":"string"}},"required":["topic"]}},
 "music.prepare":{"approval":True,"description":"Prepare an audio-production job.",
   "schema":{"type":"object","properties":{"file_name":{"type":"string"}},"required":["file_name"]}},
 "freelance.prepare":{"approval":False,"description":"Prepare a client-work checklist.",
   "schema":{"type":"object","properties":{"brief":{"type":"string"}},"required":["brief"]}}
}

def validate(call):
    if not call:return True,""
    name=call.get("name","")
    if name not in TOOLS:return False,"Guri security: action is not registered."
    raw=(name+" "+str(call.get("arguments",{}))).lower()
    if any(x in raw for x in BLOCKED_TERMS):
        return False,"Guri security: financial/credential action blocked."
    if name=="web.open_url" and not str(call.get("arguments",{}).get("url","")).startswith("https://"):
        return False,"Only HTTPS URLs are allowed."
    return True,""

def needs_approval(call):
    return bool(TOOLS.get(call.get("name",""),{}).get("approval",False))
