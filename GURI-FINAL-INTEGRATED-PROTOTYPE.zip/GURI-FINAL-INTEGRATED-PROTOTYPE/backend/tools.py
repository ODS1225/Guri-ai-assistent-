from db import reminder_create
from trends import search as trend_search
from content import plan,assets

def execute(call):
    name=call.get("name"); a=call.get("arguments",{})
    if name=="web.open_url":
        return {"ok":True,"type":"open_url","url":a["url"]}
    if name=="scheduler.create_reminder":
        return {"ok":True,"type":"reminder","id":reminder_create(a["text"],a["run_at"]),
                "text":a["text"],"run_at":a["run_at"]}
    if name=="device.show_notification":
        return {"ok":True,"type":"notification","text":a["text"]}
    if name=="device.share_text":
        return {"ok":True,"type":"share_text","text":a["text"]}
    if name=="trend.search": return trend_search(a.get("query",""))
    if name=="content.make_plan":
        return {"ok":True,"type":"content_plan",**plan(a["topic"],a.get("platform","Instagram/YouTube"),a.get("language","Hinglish"))}
    if name=="content.generate_assets":
        return {"ok":True,"type":"content_assets",**assets(a["topic"])}
    if name=="music.prepare":
        return {"ok":True,"type":"music_job","file_name":a["file_name"],
                "steps":["cleanup","noise reduction","arrangement","mix","master","export"]}
    if name=="freelance.prepare":
        return {"ok":True,"type":"freelance_job","brief":a["brief"],
                "steps":["requirements","deliverables","timeline","draft","review","client message"]}
    return {"ok":False,"error":"Executor not implemented."}
