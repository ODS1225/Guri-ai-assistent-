import json,urllib.request
from config import AI_BASE_URL,AI_API_KEY,AI_MODEL
from security import TOOLS

SYSTEM="""You are Guri, a private multilingual personal AI assistant.
Understand Hindi, English, Punjabi and Hinglish.
Reply naturally in the user's language.
Be practical and honest about what you can execute.
Use registered tools when an action is requested.
Never invent a tool or claim an action succeeded without a tool result.
Never request or process banking credentials, OTPs, PINs or financial transfers.
Consequential external actions wait for the application's approval gate."""

class ProviderError(Exception): pass

class Provider:
    def chat(self,history,language="auto"):
        if not(AI_BASE_URL and AI_API_KEY and AI_MODEL):
            raise ProviderError("AI provider is not configured on the server.")
        defs=[]
        for name,v in TOOLS.items():
            defs.append({"type":"function","function":{
                "name":name,"description":v["description"],"parameters":v["schema"]}})
        payload={"model":AI_MODEL,
                 "messages":[{"role":"system","content":SYSTEM},
                             {"role":"system","content":f"Language: {language}"}]+history,
                 "tools":defs,"tool_choice":"auto","temperature":0.35}
        req=urllib.request.Request(
            AI_BASE_URL+"/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Content-Type":"application/json","Authorization":"Bearer "+AI_API_KEY})
        try:
            with urllib.request.urlopen(req,timeout=90) as r:
                data=json.loads(r.read().decode())
        except Exception as e:
            raise ProviderError(str(e))
        msg=data["choices"][0]["message"]; call=None
        if msg.get("tool_calls"):
            fn=msg["tool_calls"][0]["function"]
            call={"name":fn["name"],"arguments":json.loads(fn.get("arguments","{}"))}
        return {"text":msg.get("content") or "Action ready.","tool_call":call}
