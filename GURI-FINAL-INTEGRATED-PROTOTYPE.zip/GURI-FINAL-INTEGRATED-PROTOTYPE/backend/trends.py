import urllib.request,xml.etree.ElementTree as ET,time
FEEDS=[
 "https://news.google.com/rss?hl=en-IN&gl=IN&ceid=IN:en",
 "https://news.google.com/rss?hl=hi&gl=IN&ceid=IN:hi"
]
def search(query=""):
    q=query.lower().strip(); out=[]; seen=set()
    for url in FEEDS:
        try:
            data=urllib.request.urlopen(url,timeout=8).read()
            root=ET.fromstring(data)
            for n in root.findall(".//item")[:30]:
                title=n.findtext("title") or ""
                if q and q not in title.lower(): continue
                k=title.lower()
                if k in seen: continue
                seen.add(k); out.append({"title":title,"url":n.findtext("link") or "","source":"Google News RSS"})
        except Exception: pass
    return {"items":out[:30],"generated_at":int(time.time())}
