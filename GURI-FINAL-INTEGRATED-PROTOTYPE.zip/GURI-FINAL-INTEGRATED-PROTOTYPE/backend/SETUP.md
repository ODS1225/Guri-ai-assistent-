# Backend setup

1. Create a Python virtual environment.
2. pip install -r requirements.txt
3. Copy .env.example to .env and load variables into the environment.
4. Configure an OpenAI-compatible AI provider.
5. Run: python app.py
6. Put the backend behind HTTPS in production.
7. Never put AI_API_KEY inside the Android app.
