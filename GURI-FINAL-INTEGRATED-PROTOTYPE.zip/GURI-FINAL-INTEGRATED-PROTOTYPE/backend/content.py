def plan(topic,platform="Instagram/YouTube",language="Hinglish"):
    return {
      "topic":topic,"platform":platform,"language":language,
      "deliverables":["3 hooks","45-60 sec script","scene breakdown",
        "visual prompts","voice-over","music direction","caption",
        "hashtags","thumbnail concept","upload checklist"],
      "workflow":["research","angle","script","visuals","voice",
        "edit","review","schedule/publish"]
    }

def assets(topic):
    return {"topic":topic,"status":"production_plan",
      "files":["script.txt","scene_prompts.txt","voiceover.txt",
               "caption.txt","thumbnail_prompt.txt"],
      "note":"Actual media generation requires configured providers."}
