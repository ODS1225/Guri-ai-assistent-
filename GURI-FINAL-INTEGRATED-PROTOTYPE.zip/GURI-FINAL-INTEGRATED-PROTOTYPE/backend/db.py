import sqlite3,json,time,uuid
from config import DB_PATH

def conn():
    c=sqlite3.connect(DB_PATH); c.row_factory=sqlite3.Row; return c

def init():
    c=conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS conversations(id TEXT PRIMARY KEY,created INTEGER);
    CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT,
      conversation_id TEXT,role TEXT,content TEXT,created INTEGER);
    CREATE TABLE IF NOT EXISTS approvals(id TEXT PRIMARY KEY,tool_call TEXT,
      status TEXT,result TEXT,created INTEGER);
    CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,
      event TEXT,data TEXT,created INTEGER);
    CREATE TABLE IF NOT EXISTS reminders(id TEXT PRIMARY KEY,text TEXT,
      run_at TEXT,status TEXT,created INTEGER);
    """)
    c.commit(); c.close()

def create_conversation():
    cid=str(uuid.uuid4()); c=conn()
    c.execute("INSERT INTO conversations VALUES (?,?)",(cid,int(time.time())))
    c.commit(); c.close(); return cid

def conversation_exists(cid):
    c=conn(); r=c.execute("SELECT id FROM conversations WHERE id=?",(cid,)).fetchone()
    c.close(); return r is not None

def add_message(cid,role,content):
    c=conn(); c.execute(
      "INSERT INTO messages(conversation_id,role,content,created) VALUES(?,?,?,?)",
      (cid,role,content,int(time.time()))); c.commit(); c.close()

def messages(cid,limit=80):
    c=conn(); rows=c.execute(
      "SELECT role,content FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT ?",
      (cid,limit)).fetchall(); c.close()
    return [dict(r) for r in reversed(rows)]

def approval_create(call):
    aid=str(uuid.uuid4()); c=conn()
    c.execute("INSERT INTO approvals VALUES(?,?,?,?,?)",
      (aid,json.dumps(call),"pending",None,int(time.time())))
    c.commit(); c.close(); return aid

def approval_get(aid):
    c=conn(); r=c.execute("SELECT * FROM approvals WHERE id=?",(aid,)).fetchone(); c.close()
    if not r:return None
    d=dict(r); d["tool_call"]=json.loads(d["tool_call"]); return d

def approvals_pending():
    c=conn(); rows=c.execute(
      "SELECT * FROM approvals WHERE status='pending' ORDER BY created DESC").fetchall(); c.close()
    out=[]
    for r in rows:
        d=dict(r); d["tool_call"]=json.loads(d["tool_call"]); out.append(d)
    return out

def approval_finish(aid,status,result=None):
    c=conn(); c.execute("UPDATE approvals SET status=?,result=? WHERE id=?",
      (status,json.dumps(result) if result is not None else None,aid)); c.commit(); c.close()

def audit(event,data):
    c=conn(); c.execute("INSERT INTO audit(event,data,created) VALUES(?,?,?)",
      (event,json.dumps(data,ensure_ascii=False),int(time.time()))); c.commit(); c.close()

def audit_list(limit=200):
    c=conn(); rows=c.execute("SELECT * FROM audit ORDER BY id DESC LIMIT ?",(limit,)).fetchall(); c.close()
    return [dict(r) for r in rows]

def reminder_create(text,run_at):
    rid=str(uuid.uuid4()); c=conn()
    c.execute("INSERT INTO reminders VALUES(?,?,?,?,?)",
      (rid,text,run_at,"scheduled",int(time.time())))
    c.commit(); c.close(); return rid

init()
